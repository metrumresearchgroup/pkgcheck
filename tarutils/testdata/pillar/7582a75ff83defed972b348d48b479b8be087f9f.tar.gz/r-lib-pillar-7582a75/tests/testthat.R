library(testthat)
library(pillar)

test_check("pillar")
