library(testthat)
library(testnote)

test_check("testnote")
