#' calculate a median
#' @param something param doesn't exist
#' @param ... dots to pass to median
#' @export
my_median <- function(...) {
  stats::median(...)
}
