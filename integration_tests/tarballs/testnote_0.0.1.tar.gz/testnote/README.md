NOTE for RCMD CHECK should be about nonstandard top level file (license.md)
that is not ignored in the .Rbuildignore