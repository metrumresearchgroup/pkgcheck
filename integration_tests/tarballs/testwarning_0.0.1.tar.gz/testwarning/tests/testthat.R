library(testthat)
library(testwarning)

test_check("testwarning")
