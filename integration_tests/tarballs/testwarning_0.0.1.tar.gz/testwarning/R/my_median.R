#' calculate a median
#' @param something param doesn't exist
#' @param ... dots to pass to median
#' @export
my_median <- function(x, ...) {
  stats::median(x, ...)
}
