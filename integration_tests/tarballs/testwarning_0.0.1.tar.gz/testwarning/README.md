documentation incorrect for my_median
